<?php
echo readfile("webdictionary.txt");
?>